# AirAware · Air Quality Dashboard

**Domain:** Agriculture, Environment & Smart City  **Theme:** Air Quality Dashboard

AirAware teaches people how to read the Air Quality Index (AQI) and then shows live air quality for cities around the world. It is built in two phases, exactly as the project brief describes.

| Phase | Modules | What it covers | Where to look |
|---|---|---|---|
| Static | 1–2 | AQI scale explainer page, CSS Grid, mobile-first media queries | `index.html`, `styles.css` |
| Dynamic | 3–4 | City AQI from an API, colour-coded cards, trend chart, TypeScript + Fetch API with typed data | `src/*.ts` → `script.js` |

![Hero](docs/hero.png)

## Quick start

No installation is needed to *run* it. Open `index.html` in a browser (an internet connection is needed for live data).

To change the code, edit the TypeScript in `src/` and rebuild:

```bash
npm install          # installs TypeScript (once)
npm run build        # compiles src/*.ts and bundles script.js
npm test             # builds, then runs the unit tests
npm run typecheck    # strict type-check only
```

## Requirements checklist

### Static phase (HTML / CSS)
- [x] **AQI scale explainer**: six official US EPA bands (0–500), each with colour, range, icon and health advice (`#scale`).
- [x] **CSS Grid**: band cards, pollutant cards, tips and city cards all use `display: grid` with `grid-template-columns`.
- [x] **Mobile-first media queries**: base styles target phones; `min-width` queries at 640px, 960px and 1200px add columns (1 → 2 → 3 → 4).
- [x] **Semantic, accessible HTML**: landmarks (`header`, `main`, `nav`, `footer`), one `h1`, ordered headings, skip link, `aria-live` regions, labelled controls, visible focus styles, `<noscript>` message.
- [x] **Smooth animations and transitions**: scroll-reveal, animated scale bar, count-up numbers, progress rings, drawn-in sparklines and chart line, hover/active states. All respect `prefers-reduced-motion`.

### Dynamic phase (TypeScript + Fetch API)
- [x] **City AQI via an API**: [Open-Meteo Air Quality API](https://open-meteo.com/en/docs/air-quality-api) (free, no key) using the Fetch API with `async/await`.
- [x] **Typed data**: interfaces for every API shape (`AirQualityResponse`, `GeocodeResult`, `CityReading`…), a discriminated union for per-card state (`Slot`), and a **runtime type guard** (`isAirQualityResponse`) because TypeScript types disappear at runtime. `tsconfig.json` uses `"strict": true`.
- [x] **Colour-coded cards**: each city card takes its colour, ring and label from the AQI band.
- [x] **Trend chart**: 72-hour hand-built SVG line chart (no chart library) with AQI-band background stripes, a colour-graded line, smooth curve, hover/touch tooltip and axis labels.
- [x] **Search**: look up any city (Open-Meteo geocoding), add it, remove it; custom cities persist in `localStorage`.
- [x] **Robustness**: loading skeletons, per-card error state with *Try again*, malformed-response detection, and a clearly labelled sample-data fallback when the service is unreachable. Auto-refresh every 10 minutes.

![Dashboard](docs/dashboard.png)

## Project structure

```
index.html          Page markup (static explainer + dashboard shell)
styles.css          Mobile-first CSS: design tokens, Grid layouts, animations
script.js           Generated bundle loaded by the page (do not edit by hand)
build.mjs           Compiles src/*.ts with tsc and bundles script.js
src/
  types.ts          Shared interfaces and the Slot union type
  aqi.ts            AQI bands, getBand(), formatting helpers
  api.ts            Typed Fetch calls, response type guard, offline sample data
  chart.ts          SVG trend chart and sparklines
  ui.ts             Animations, scroll reveal, card templates
  main.ts           State, events and start-up
tests/aqi.test.mjs  Unit tests (band boundaries, formatting, validation)
docs/               Screenshots used in this README
```

## How it works

1. `main.ts` builds one card slot per city and calls `fetchAirQuality()` for all of them in parallel (`Promise.all`).
2. `api.ts` requests `current` values plus 72 hours of hourly `us_aqi`, validates the JSON with `isAirQualityResponse()`, and returns a typed `CityReading`.
3. Each slot is a `Slot` (`loading | ready | error`), so one failing city never breaks the others.
4. `getBand()` maps an AQI number to its band, which drives every colour and message in the UI.
5. `chart.ts` turns the hourly points into SVG paths (Catmull-Rom smoothing) and wires the tooltip.

## Testing

`npm test` runs 11 unit tests covering every AQI band boundary (0, 50, 51 … 500), out-of-range values, HTML escaping, API response validation, 72-hour trimming and the sample-data fallback.

The interface was also checked in a real browser at desktop (1280px) and phone (390px) widths: no horizontal overflow, no console errors, slider and cards update correctly, search and persistence work, and both the offline and malformed-response paths fall back gracefully.

| AQI scale | Mobile |
|---|---|
| ![AQI scale](docs/aqi-scale.png) | ![Mobile](docs/mobile.png) |

*Screenshots were captured with sample API responses.*

## Data and credits

Air-quality and geocoding data by [Open-Meteo](https://open-meteo.com/) (CC BY 4.0). AQI bands follow the US EPA scale. AQI values are indicative and not a substitute for official health advice.
