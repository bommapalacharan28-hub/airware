// Unit tests for the pure logic (AQI bands, formatting, API response validation).
// Run with:  node tests/aqi.test.mjs   (after `node build.mjs`)
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";

// Load the compiled modules into one sandbox so their globals are shared, like in the browser.
const sandbox = {};
vm.createContext(sandbox);
for (const file of ["aqi", "api"]) {
  vm.runInContext(readFileSync(`dist/${file}.js`, "utf8"), sandbox);
}
const run = (code) => vm.runInContext(code, sandbox);

let passed = 0;
function test(name, fn) {
  fn();
  passed++;
  console.log("  ✓", name);
}

console.log("AQI bands");
test("band boundaries follow the US EPA scale", () => {
  const cases = [[0, "good"], [50, "good"], [51, "moderate"], [100, "moderate"], [101, "sensitive"],
    [150, "sensitive"], [151, "unhealthy"], [200, "unhealthy"], [201, "very-unhealthy"],
    [300, "very-unhealthy"], [301, "hazardous"], [500, "hazardous"]];
  for (const [aqi, key] of cases) assert.equal(run(`getBand(${aqi}).key`), key, `AQI ${aqi}`);
});
test("values above 500 map to Hazardous", () => assert.equal(run("getBand(742).key"), "hazardous"));
test("negative values clamp to Good", () => assert.equal(run("getBand(-5).key"), "good"));
test("decimals are rounded before lookup", () => assert.equal(run("getBand(50.6).key"), "moderate"));
test("bands cover 0-500 with no gaps", () => {
  const bands = run("BANDS.map(b => [b.min, b.max])");
  assert.equal(bands[0][0], 0);
  assert.equal(bands.at(-1)[1], 500);
  for (let i = 1; i < bands.length; i++) assert.equal(bands[i][0], bands[i - 1][1] + 1);
});

console.log("Formatting helpers");
test("formatStamp makes a readable local time", () => assert.equal(run('formatStamp("2026-11-17T10:00")'), "17 Nov, 10:00"));
test("escapeHtml neutralises markup", () => {
  assert.equal(run(`escapeHtml('<img src=x onerror="a">')`), "&lt;img src=x onerror=&quot;a&quot;&gt;");
});

console.log("API response validation");
test("accepts a well-formed response", () => {
  const ok = { current: { time: "2026-11-17T10:00" }, hourly: { time: ["a"], us_aqi: [42] } };
  sandbox.ok = ok;
  assert.equal(run("isAirQualityResponse(ok)"), true);
});
test("rejects malformed responses", () => {
  for (const bad of [null, "x", {}, { current: {}, hourly: {} }, { current: { time: "t" }, hourly: { time: [1], us_aqi: [] } }]) {
    sandbox.bad = bad;
    assert.equal(run("isAirQualityResponse(bad)"), false);
  }
});
test("parseTrend keeps only past hours with data, max 72", () => {
  const time = [], us_aqi = [];
  for (let i = 0; i < 100; i++) { time.push(`2026-11-1${i < 50 ? 5 : 6}T${String(i % 24).padStart(2, "0")}:00`); us_aqi.push(i === 3 ? null : 40 + i); }
  sandbox.data = { current: { time: "2026-11-16T23:00" }, hourly: { time, us_aqi } };
  const length = run("parseTrend(data).length");
  assert.ok(length <= 72 && length > 0);
});
test("sample data is deterministic and flagged as sample", () => {
  sandbox.c = { id: "delhi", name: "Delhi", country: "India", latitude: 1, longitude: 1 };
  assert.equal(run("sampleReading(c).sample"), true);
  assert.equal(run("sampleReading(c).aqi"), run("sampleReading(c).aqi"));
  assert.equal(run("sampleReading(c).trend.length"), 72);
});

console.log(`\n${passed} tests passed`);
