// ---------------------------------------------------------------
// aqi.ts — the AQI scale and small formatting helpers.
// ---------------------------------------------------------------

const BANDS: readonly AqiBand[] = [
  { key: "good", label: "Good", min: 0, max: 50, color: "#3ddc84", icon: "😊",
    advice: "Air quality is satisfactory. A great day for outdoor activities." },
  { key: "moderate", label: "Moderate", min: 51, max: 100, color: "#ffd93d", icon: "🙂",
    advice: "Acceptable for most people. Unusually sensitive individuals should consider limiting long outdoor exertion." },
  { key: "sensitive", label: "Unhealthy for Sensitive Groups", min: 101, max: 150, color: "#ff9f43", icon: "😷",
    advice: "Children, older adults and people with heart or lung conditions should reduce prolonged outdoor exertion." },
  { key: "unhealthy", label: "Unhealthy", min: 151, max: 200, color: "#ff5d5d", icon: "🤢",
    advice: "Everyone may begin to feel effects. Limit outdoor exertion and consider a mask outside." },
  { key: "very-unhealthy", label: "Very Unhealthy", min: 201, max: 300, color: "#b361ff", icon: "🚨",
    advice: "Health alert. Avoid outdoor activity, keep windows closed and use an air purifier if you have one." },
  { key: "hazardous", label: "Hazardous", min: 301, max: 500, color: "#e0245e", icon: "☠️",
    advice: "Emergency conditions. Stay indoors with filtered air and follow local health guidance." },
];

/** Find the band for an AQI value (values above 500 map to Hazardous). */
function getBand(aqi: number): AqiBand {
  const value = Math.max(0, Math.round(aqi));
  return BANDS.find((band) => value <= band.max) ?? BANDS[BANDS.length - 1];
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** "2026-11-17T10:00" → "17 Nov, 10:00" (no timezone maths, the API already gives local time). */
function formatStamp(iso: string): string {
  const [date, time = "00:00"] = iso.split("T");
  const [, month, day] = date.split("-").map(Number);
  return `${day} ${MONTHS[month - 1] ?? ""}, ${time.slice(0, 5)}`;
}

function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (ch) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch] as string
  ));
}
