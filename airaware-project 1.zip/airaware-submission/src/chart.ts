// ---------------------------------------------------------------
// chart.ts — hand-built SVG charts (no libraries): the 72h trend
// chart with animated line + hover tooltip, and tiny card sparklines.
// ---------------------------------------------------------------

const CHART_W = 860;
const CHART_H = 340;
const CHART_PAD = { left: 46, right: 18, top: 16, bottom: 34 };
const Y_STEPS = [100, 150, 200, 300, 400, 500];
const Y_TICKS = [0, 50, 100, 150, 200, 300, 400, 500];

/** Smooth curve through points using Catmull-Rom → cubic Bézier conversion. */
function smoothPath(points: [number, number][]): string {
  if (points.length < 2) return "";
  let d = `M${points[0][0].toFixed(1)},${points[0][1].toFixed(1)}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const c1x = p1[0] + (p2[0] - p0[0]) / 6;
    const c1y = p1[1] + (p2[1] - p0[1]) / 6;
    const c2x = p2[0] - (p3[0] - p1[0]) / 6;
    const c2y = p2[1] - (p3[1] - p1[1]) / 6;
    d += ` C${c1x.toFixed(1)},${c1y.toFixed(1)} ${c2x.toFixed(1)},${c2y.toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
  }
  return d;
}

/** Tiny sparkline for the last 24 hours, drawn in with a CSS animation. */
function sparkline(values: number[], color: string): string {
  const recent = values.slice(-24);
  if (recent.length < 2) return "";
  const w = 240;
  const h = 40;
  const min = Math.min(...recent);
  const span = Math.max(1, Math.max(...recent) - min);
  const coords = recent.map((v, i): [number, number] => [
    (i / (recent.length - 1)) * w,
    h - 3 - ((v - min) / span) * (h - 6),
  ]);
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" aria-hidden="true">
    <path d="${smoothPath(coords)}" fill="none" stroke="${color}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" pathLength="1"/>
  </svg>`;
}

function niceMax(value: number): number {
  const target = value * 1.12;
  return Y_STEPS.find((step) => step >= target) ?? 500;
}

/** Render the trend chart for one city into `host`, with draw-in animation and hover tooltip. */
function renderTrendChart(host: HTMLElement, reading: CityReading): void {
  const points = reading.trend;
  if (points.length < 2) {
    host.innerHTML = `<p class="chart-empty">Not enough hourly data to draw a trend for this city.</p>`;
    return;
  }

  const { left, right, top, bottom } = CHART_PAD;
  const innerW = CHART_W - left - right;
  const innerH = CHART_H - top - bottom;
  const yMax = niceMax(Math.max(...points.map((p) => p.aqi)));
  const n = points.length;

  const xAt = (i: number): number => left + (i / (n - 1)) * innerW;
  const yAt = (v: number): number => top + innerH - (Math.min(v, yMax) / yMax) * innerH;

  const coords = points.map((p, i): [number, number] => [xAt(i), yAt(p.aqi)]);
  const linePath = smoothPath(coords);
  const areaPath = `${linePath} L${xAt(n - 1).toFixed(1)},${(top + innerH).toFixed(1)} L${xAt(0).toFixed(1)},${(top + innerH).toFixed(1)} Z`;

  // Coloured background stripes, one per visible AQI band
  const visibleBands = BANDS.filter((band) => band.min < yMax);
  const stripes = visibleBands.map((band) => {
    const lower = band.min === 0 ? 0 : band.min - 1;
    const upper = Math.min(band.max, yMax);
    return `<rect x="${left}" y="${yAt(upper).toFixed(1)}" width="${innerW}" height="${(yAt(lower) - yAt(upper)).toFixed(1)}" fill="${band.color}" opacity="0.07"/>`;
  }).join("");

  // Line colour follows the AQI value: gradient stops at the middle of each band
  const stops = visibleBands.map((band) => {
    const mid = Math.min((band.min + Math.min(band.max, yMax)) / 2, yMax);
    return `<stop offset="${((1 - mid / yMax) * 100).toFixed(1)}%" stop-color="${band.color}"/>`;
  }).reverse().join("");

  const yTicks = Y_TICKS.filter((t) => t <= yMax);
  const grid = yTicks.map((t) => `
    <line x1="${left}" x2="${left + innerW}" y1="${yAt(t).toFixed(1)}" y2="${yAt(t).toFixed(1)}"/>`).join("");
  const yLabels = yTicks.map((t) => `
    <text x="${left - 8}" y="${(yAt(t) + 4).toFixed(1)}" text-anchor="end">${t}</text>`).join("");

  const tickCount = 5;
  const xLabels = Array.from({ length: tickCount }, (_, k) => {
    const index = Math.round((k / (tickCount - 1)) * (n - 1));
    const anchor = k === 0 ? "start" : k === tickCount - 1 ? "end" : "middle";
    return `<text x="${xAt(index).toFixed(1)}" y="${CHART_H - 10}" text-anchor="${anchor}">${escapeHtml(points[index].label)}</text>`;
  }).join("");

  const last = coords[n - 1];
  const lastColor = reading.band.color;

  host.innerHTML = `
    <div class="chart-canvas">
      <svg viewBox="0 0 ${CHART_W} ${CHART_H}" role="img" aria-label="Line chart of hourly US AQI for ${escapeHtml(reading.city.name)} over the last ${n} hours">
        <defs>
          <linearGradient id="line-grad" gradientUnits="userSpaceOnUse" x1="0" y1="${top}" x2="0" y2="${top + innerH}">${stops}</linearGradient>
          <linearGradient id="fade-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="${lastColor}" stop-opacity="0.35"/>
            <stop offset="100%" stop-color="${lastColor}" stop-opacity="0"/>
          </linearGradient>
        </defs>
        ${stripes}
        <g class="chart-grid">${grid}</g>
        <g class="chart-axis">${yLabels}${xLabels}</g>
        <path class="chart-area" d="${areaPath}" fill="url(#fade-grad)"/>
        <path class="chart-line" d="${linePath}" stroke="url(#line-grad)"/>
        <circle class="last-pulse" cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="5" stroke="${lastColor}"/>
        <circle class="last-dot" cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="6" fill="${lastColor}" stroke="#fff" stroke-width="2"/>
        <line class="hover-line" y1="${top}" y2="${top + innerH}" x1="0" x2="0"/>
        <circle class="hover-dot" r="6" cx="0" cy="0" stroke="${lastColor}"/>
        <rect class="chart-hit" x="${left}" y="${top}" width="${innerW}" height="${innerH}" fill="transparent"/>
      </svg>
      <div class="chart-tip" role="presentation"></div>
    </div>`;

  const canvas = host.querySelector<HTMLElement>(".chart-canvas");
  const svg = host.querySelector<SVGSVGElement>("svg");
  const line = host.querySelector<SVGPathElement>(".chart-line");
  const hit = host.querySelector<SVGRectElement>(".chart-hit");
  const hoverLine = host.querySelector<SVGLineElement>(".hover-line");
  const hoverDot = host.querySelector<SVGCircleElement>(".hover-dot");
  const tip = host.querySelector<HTMLElement>(".chart-tip");
  if (!canvas || !svg || !line || !hit || !hoverLine || !hoverDot || !tip) return;

  // Draw the line in from left to right
  if (!prefersReducedMotion()) {
    const length = line.getTotalLength();
    line.style.strokeDasharray = `${length}`;
    line.style.strokeDashoffset = `${length}`;
    void line.getBoundingClientRect(); // force reflow so the transition starts from the hidden state
    line.style.transition = "stroke-dashoffset 1.6s cubic-bezier(0.22, 0.8, 0.25, 1)";
    line.style.strokeDashoffset = "0";
  }

  // Hover / touch tooltip: snap to the nearest hourly point
  const move = (event: PointerEvent): void => {
    const box = svg.getBoundingClientRect();
    const scale = CHART_W / box.width;
    const px = (event.clientX - box.left) * scale;
    const index = Math.min(n - 1, Math.max(0, Math.round(((px - left) / innerW) * (n - 1))));
    const point = points[index];
    const [cx, cy] = coords[index];
    const band = getBand(point.aqi);

    hoverLine.setAttribute("x1", cx.toFixed(1));
    hoverLine.setAttribute("x2", cx.toFixed(1));
    hoverDot.setAttribute("cx", cx.toFixed(1));
    hoverDot.setAttribute("cy", cy.toFixed(1));
    hoverDot.setAttribute("stroke", band.color);

    tip.style.left = `${(cx / CHART_W) * box.width}px`;
    tip.style.top = `${(cy / CHART_H) * box.height}px`;
    tip.innerHTML = `<strong style="color:${band.color}">${point.aqi}</strong>${escapeHtml(band.label)}<span>${escapeHtml(point.label)}</span>`;
    canvas.classList.add("is-hover");
  };
  hit.addEventListener("pointermove", move);
  hit.addEventListener("pointerdown", move);
  hit.addEventListener("pointerleave", () => canvas.classList.remove("is-hover"));
}
