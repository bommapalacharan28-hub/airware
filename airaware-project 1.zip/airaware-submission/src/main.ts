// ---------------------------------------------------------------
// main.ts — app state, events and start-up.
// ---------------------------------------------------------------

const STORAGE_KEY = "airaware.customCities.v1";
const AUTO_REFRESH_MS = 10 * 60 * 1000;

const slots = new Map<string, Slot>();
let cities: City[] = [];
let selectedId = "";
let searchResults: GeocodeResult[] = [];

// ---------- Element references ----------
const grid = byId<HTMLUListElement>("city-grid");
const refreshButton = byId<HTMLButtonElement>("refresh-btn");
const updatedAt = byId<HTMLElement>("updated-at");
const banner = byId<HTMLElement>("banner");
const searchForm = byId<HTMLFormElement>("search-form");
const searchInput = byId<HTMLInputElement>("city-search");
const resultsList = byId<HTMLUListElement>("search-results");
const panel = document.querySelector<HTMLElement>(".trend-panel");
const panelBody = byId<HTMLElement>("panel-body");
const trendTitle = byId<HTMLElement>("trend-title");
const trendSub = byId<HTMLElement>("trend-sub");
const trendBadge = byId<HTMLElement>("trend-badge");
const trendStats = byId<HTMLElement>("trend-stats");
const trendAdvice = byId<HTMLElement>("trend-advice");
const chartHost = byId<HTMLElement>("chart-host");

// ---------- Saved custom cities ----------

function isCity(value: unknown): value is City {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  return typeof v.id === "string" && typeof v.name === "string" && typeof v.country === "string"
    && typeof v.latitude === "number" && typeof v.longitude === "number";
}

function loadCustomCities(): City[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter(isCity).map((c) => ({ ...c, custom: true })) : [];
  } catch {
    return [];
  }
}

function saveCustomCities(): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cities.filter((c) => c.custom)));
  } catch {
    /* storage unavailable (private mode) — safe to ignore */
  }
}

// ---------- Rendering ----------

function slotElement(cityId: string): HTMLElement | null {
  return grid.querySelector<HTMLElement>(`[data-city="${CSS.escape(cityId)}"]`);
}

function renderSlot(city: City): void {
  const element = slotElement(city.id);
  const slot = slots.get(city.id);
  if (!element || !slot) return;

  if (slot.status === "loading") {
    element.innerHTML = skeletonHtml();
  } else if (slot.status === "error") {
    element.innerHTML = errorHtml(city, slot.message);
  } else {
    element.innerHTML = cardHtml(slot.reading, city.id === selectedId);
    animateCounters(element);
  }
}

function buildGrid(): void {
  grid.innerHTML = cities
    .map((city, index) => `<li class="city-slot reveal" data-city="${escapeHtml(city.id)}" style="--i:${index % 4}"></li>`)
    .join("");
  cities.forEach(renderSlot);
  observeReveals(grid);
}

function renderPanel(): void {
  const slot = slots.get(selectedId);
  if (!slot || slot.status !== "ready") {
    trendTitle.textContent = slot?.status === "error" ? "Data unavailable" : "Loading trend…";
    trendSub.textContent = "";
    trendBadge.textContent = "";
    trendBadge.removeAttribute("style");
    trendStats.innerHTML = "";
    trendAdvice.textContent = "";
    chartHost.innerHTML = `<div class="chart-loading"></div>`;
    return;
  }

  const { reading } = slot;
  const { city, band } = reading;
  panel?.style.setProperty("--band", band.color);
  trendTitle.textContent = `${city.name} · last ${reading.trend.length} hours`;
  trendSub.textContent = reading.sample
    ? "Sample data shown because the live service could not be reached."
    : `${city.country} · US AQI by hour · source: Open-Meteo`;
  trendBadge.innerHTML = `<span aria-hidden="true">${band.icon}</span> ${escapeHtml(band.label)}`;
  trendStats.innerHTML = statsHtml(reading);
  trendAdvice.textContent = band.advice;

  panelBody.classList.remove("swap");
  void panelBody.offsetWidth; // restart the fade-up animation
  panelBody.classList.add("swap");

  animateCounters(trendStats);
  renderTrendChart(chartHost, reading);
}

function selectCity(cityId: string): void {
  selectedId = cityId;
  grid.querySelectorAll<HTMLButtonElement>(".city-card").forEach((card) => {
    const active = card.dataset.select === cityId;
    card.classList.toggle("is-selected", active);
    card.setAttribute("aria-pressed", String(active));
  });
  renderPanel();
}

function updateBanner(): void {
  const all = [...slots.values()];
  const readings = all.filter((s): s is { status: "ready"; reading: CityReading } => s.status === "ready");
  const errors = all.filter((s) => s.status === "error").length;

  if (readings.length > 0 && readings.every((s) => s.reading.sample)) {
    banner.textContent = "⚠️ Couldn't reach the live air-quality service, so sample data is shown. Check your connection and press refresh.";
    banner.hidden = false;
  } else if (errors > 0) {
    banner.textContent = `⚠️ ${errors} ${errors === 1 ? "city" : "cities"} couldn't be loaded. Use "Try again" on the card.`;
    banner.hidden = false;
  } else {
    banner.hidden = true;
  }
}

// ---------- Loading data ----------

/** Load one city. Never throws; returns true when live data arrived. */
async function loadCity(city: City): Promise<boolean> {
  const previous = slots.get(city.id);
  if (!previous || previous.status !== "ready") {
    slots.set(city.id, { status: "loading" });
    renderSlot(city);
    if (city.id === selectedId) renderPanel();
  }
  try {
    const reading = await fetchAirQuality(city);
    slots.set(city.id, { status: "ready", reading });
    renderSlot(city);
    if (city.id === selectedId) renderPanel();
    return true;
  } catch (error) {
    if (previous?.status === "ready" && !previous.reading.sample) return false; // keep stale live data
    const message = error instanceof Error ? error.message : "unknown error";
    slots.set(city.id, { status: "error", message });
    renderSlot(city);
    if (city.id === selectedId) renderPanel();
    return false;
  }
}

async function loadAll(): Promise<void> {
  refreshButton.disabled = true;
  refreshButton.classList.add("is-spinning");

  const results = await Promise.all(cities.map(loadCity));

  // Nothing worked (probably offline): fall back to clearly-labelled sample data
  if (results.every((ok) => !ok)) {
    cities.forEach((city) => {
      slots.set(city.id, { status: "ready", reading: sampleReading(city) });
      renderSlot(city);
    });
    renderPanel();
  }

  updateBanner();
  const now = new Date();
  updatedAt.textContent = `Refreshed ${now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
  refreshButton.classList.remove("is-spinning");
  refreshButton.disabled = false;
}

// ---------- Adding / removing cities ----------

async function addCity(result: GeocodeResult): Promise<void> {
  const id = `geo-${result.id}`;
  const existing = cities.find((c) => c.id === id);
  if (existing) {
    selectCity(existing.id);
    slotElement(existing.id)?.scrollIntoView({ behavior: "smooth", block: "center" });
    return;
  }

  const city: City = {
    id,
    name: result.name,
    country: result.country ?? result.admin1 ?? "",
    latitude: result.latitude,
    longitude: result.longitude,
    custom: true,
  };
  cities.push(city);
  saveCustomCities();

  const item = document.createElement("li");
  item.className = "city-slot reveal";
  item.dataset.city = id;
  grid.appendChild(item);
  observeReveals(grid);

  selectedId = id;
  const ok = await loadCity(city);
  if (!ok && slots.get(id)?.status === "error") {
    updateBanner();
    return;
  }
  selectCity(id);
  updateBanner();
}

function removeCity(cityId: string): void {
  cities = cities.filter((c) => c.id !== cityId);
  slots.delete(cityId);
  saveCustomCities();
  const element = slotElement(cityId);
  if (element) {
    element.style.transition = "opacity 0.3s, transform 0.3s";
    element.style.opacity = "0";
    element.style.transform = "scale(0.92)";
    window.setTimeout(() => element.remove(), 300);
  }
  if (selectedId === cityId && cities.length > 0) selectCity(cities[0].id);
  updateBanner();
}

// ---------- Search ----------

function closeResults(): void {
  resultsList.hidden = true;
  resultsList.innerHTML = "";
}

async function runSearch(query: string): Promise<void> {
  resultsList.hidden = false;
  resultsList.innerHTML = `<li class="result-msg">Searching…</li>`;
  try {
    searchResults = await searchCities(query);
    if (searchResults.length === 0) {
      resultsList.innerHTML = `<li class="result-msg">No cities found for “${escapeHtml(query)}”.</li>`;
      return;
    }
    resultsList.innerHTML = searchResults.map((r, i) => {
      const detail = [r.admin1, r.country].filter(Boolean).join(", ");
      return `<li><button type="button" data-add="${i}">${escapeHtml(r.name)}<small>${escapeHtml(detail)}</small></button></li>`;
    }).join("");
  } catch {
    resultsList.innerHTML = `<li class="result-msg">Search is unavailable right now. Please try again.</li>`;
  }
}

// ---------- Hero explorer (drag the slider) ----------

function setupDemo(): void {
  const range = byId<HTMLInputElement>("demo-range");
  const value = byId<HTMLElement>("demo-value");
  const label = byId<HTMLElement>("demo-label");
  const advice = byId<HTMLElement>("demo-advice");
  const icon = byId<HTMLElement>("demo-icon");
  const marker = byId<HTMLElement>("scale-marker");
  const bandCards = document.querySelectorAll<HTMLElement>(".band-card");
  let lastKey = "";

  const update = (): void => {
    const aqi = Number(range.value);
    const band = getBand(aqi);
    document.documentElement.style.setProperty("--demo-color", band.color);
    value.textContent = String(aqi);
    label.textContent = band.label;
    advice.textContent = band.advice;
    marker.style.left = `${(aqi / 500) * 100}%`;
    if (band.key !== lastKey) {
      lastKey = band.key;
      icon.textContent = band.icon;
      icon.animate(
        [{ transform: "scale(0.4) rotate(-25deg)", opacity: 0 }, { transform: "scale(1) rotate(0)", opacity: 1 }],
        { duration: 450, easing: "cubic-bezier(0.22, 0.8, 0.25, 1)" },
      );
      bandCards.forEach((card) => card.classList.toggle("is-active", card.dataset.band === band.key));
    }
  };

  let userTouched = false;
  range.addEventListener("input", () => {
    userTouched = true;
    update();
  });

  // Intro sweep: glide through the scale once so people see it is interactive
  const target = 72;
  update();
  if (prefersReducedMotion()) {
    range.value = String(target);
    update();
    return;
  }
  const begin = performance.now() + 500;
  const sweep = (now: number): void => {
    if (userTouched) return;
    const t = Math.min(1, Math.max(0, (now - begin) / 2200));
    const eased = 1 - Math.pow(1 - t, 3);
    range.value = String(Math.round(target * eased));
    update();
    if (t < 1) requestAnimationFrame(sweep);
  };
  requestAnimationFrame(sweep);
}

// ---------- Start-up ----------

function init(): void {
  cities = [...DEFAULT_CITIES, ...loadCustomCities()];
  selectedId = cities[0].id;

  byId<HTMLElement>("year").textContent = String(new Date().getFullYear());

  const header = document.querySelector<HTMLElement>(".site-header");
  const onScroll = (): void => {
    header?.classList.toggle("is-scrolled", window.scrollY > 8);
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  observeReveals();
  setupDemo();
  buildGrid();
  renderPanel();

  // Card clicks (event delegation keeps one listener for all cards)
  grid.addEventListener("click", (event) => {
    const target = event.target as HTMLElement;
    const remove = target.closest<HTMLElement>("[data-remove]");
    const retry = target.closest<HTMLElement>("[data-retry]");
    const card = target.closest<HTMLElement>("[data-select]");
    if (remove?.dataset.remove) {
      removeCity(remove.dataset.remove);
    } else if (retry?.dataset.retry) {
      const city = cities.find((c) => c.id === retry.dataset.retry);
      if (city) void loadCity(city).then(updateBanner);
    } else if (card?.dataset.select) {
      selectCity(card.dataset.select);
      panel?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  });

  refreshButton.addEventListener("click", () => void loadAll());

  searchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const query = searchInput.value.trim();
    if (query.length >= 2) void runSearch(query);
  });
  resultsList.addEventListener("click", (event) => {
    const button = (event.target as HTMLElement).closest<HTMLElement>("[data-add]");
    const result = button ? searchResults[Number(button.dataset.add)] : undefined;
    if (result) {
      closeResults();
      searchInput.value = "";
      void addCity(result);
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeResults();
  });
  document.addEventListener("click", (event) => {
    const target = event.target as Node;
    if (!resultsList.hidden && !resultsList.contains(target) && !searchForm.contains(target)) closeResults();
  });

  // Quietly refresh every 10 minutes while the tab is visible
  window.setInterval(() => {
    if (document.visibilityState === "visible") void loadAll();
  }, AUTO_REFRESH_MS);

  void loadAll();
}

init();
