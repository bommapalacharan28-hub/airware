// ---------------------------------------------------------------
// ui.ts — DOM helpers, animations and HTML templates.
// ---------------------------------------------------------------

function byId<T extends HTMLElement>(id: string): T {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Missing element #${id}`);
  return element as T;
}

function prefersReducedMotion(): boolean {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/** Count a number up (or between two values) with an ease-out curve. */
function animateNumber(element: HTMLElement, to: number, duration = 1000, from = 0): void {
  if (prefersReducedMotion()) {
    element.textContent = String(to);
    return;
  }
  const start = performance.now();
  const step = (now: number): void => {
    const t = Math.min(1, (now - start) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    element.textContent = String(Math.round(from + (to - from) * eased));
    if (t < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

/** Animate every [data-count] element inside `root`. */
function animateCounters(root: ParentNode): void {
  root.querySelectorAll<HTMLElement>("[data-count]").forEach((element) => {
    animateNumber(element, Number(element.dataset.count ?? 0), 1100);
  });
}

// ---------- Scroll-reveal ----------

let revealObserver: IntersectionObserver | null = null;

function observeReveals(root: ParentNode = document): void {
  const targets = root.querySelectorAll<HTMLElement>(".reveal:not(.is-visible)");
  if (!("IntersectionObserver" in window)) {
    targets.forEach((el) => el.classList.add("is-visible"));
    return;
  }
  if (!revealObserver) {
    revealObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          revealObserver?.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
  }
  targets.forEach((el) => revealObserver?.observe(el));
}

// ---------- Card templates ----------

const RING_RADIUS = 26;
const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

function ringSvg(aqi: number): string {
  const fraction = Math.min(1, Math.max(0.04, aqi / 300));
  const offset = RING_CIRCUMFERENCE * (1 - fraction);
  return `<svg class="ring-svg" viewBox="0 0 64 64" aria-hidden="true">
    <circle class="ring-track" cx="32" cy="32" r="${RING_RADIUS}"/>
    <circle class="ring-bar" cx="32" cy="32" r="${RING_RADIUS}" transform="rotate(-90 32 32)"
      style="--c:${RING_CIRCUMFERENCE.toFixed(2)};--o:${offset.toFixed(2)}"/>
  </svg>`;
}

function formatValue(value: number | null): string {
  return value === null || value === undefined ? "–" : String(Math.round(value));
}

function cardHtml(reading: CityReading, selected: boolean): string {
  const { city, band } = reading;
  const pollutants = `PM2.5 ${formatValue(reading.pm25)} · PM10 ${formatValue(reading.pm10)} µg/m³`;
  const footer = reading.sample
    ? `<span class="sample-tag">Sample</span><span>Offline demo</span>`
    : `<span>Updated</span><span>${escapeHtml(reading.updated)}</span>`;
  const removeButton = city.custom
    ? `<button type="button" class="card-remove" data-remove="${escapeHtml(city.id)}" aria-label="Remove ${escapeHtml(city.name)}">×</button>`
    : "";

  return `
    <button type="button" class="city-card${selected ? " is-selected" : ""}" data-select="${escapeHtml(city.id)}"
            aria-pressed="${selected}" style="--band:${band.color}"
            aria-label="${escapeHtml(city.name)}: AQI ${reading.aqi}, ${escapeHtml(band.label)}. Show trend.">
      <span class="card-top">
        <span class="city-name">${escapeHtml(city.name)}</span>
        <span class="city-country">${escapeHtml(city.country)}</span>
      </span>
      <span class="card-main">
        <span class="ring">${ringSvg(reading.aqi)}<span class="ring-value" data-count="${reading.aqi}">0</span></span>
        <span class="card-band"><strong>${escapeHtml(band.label)}</strong><small>${pollutants}</small></span>
      </span>
      ${sparkline(reading.trend.map((p) => p.aqi), band.color)}
      <span class="card-foot">${footer}</span>
    </button>${removeButton}`;
}

function skeletonHtml(): string {
  return `<div class="city-skeleton" aria-label="Loading"></div>`;
}

function errorHtml(city: City, message: string): string {
  return `
    <div class="city-error">
      <strong>${escapeHtml(city.name)}</strong>
      <p>Couldn't load air quality (${escapeHtml(message)}).</p>
      <button type="button" class="btn btn-small" data-retry="${escapeHtml(city.id)}">Try again</button>
    </div>`;
}

// ---------- Trend panel pieces ----------

function statHtml(label: string, value: string, extraClass = "", count?: number): string {
  const countAttr = count !== undefined ? ` data-count="${count}"` : "";
  return `<div class="stat"><span>${label}</span><strong class="${extraClass}"${countAttr}>${value}</strong></div>`;
}

function statsHtml(reading: CityReading): string {
  const values = reading.trend.map((p) => p.aqi);
  const average = Math.round(values.reduce((sum, v) => sum + v, 0) / values.length);
  const peak = Math.max(...values);
  const dayAgo = values[Math.max(0, values.length - 25)];
  const change = values[values.length - 1] - dayAgo;
  const arrow = change > 0 ? "▲" : change < 0 ? "▼" : "■";
  const cls = change > 0 ? "up" : change < 0 ? "down" : "";

  return [
    statHtml("Now", "0", "", reading.aqi),
    statHtml("72h average", "0", "", average),
    statHtml("72h peak", "0", "", peak),
    statHtml("vs 24h ago", `${arrow} ${Math.abs(change)}`, cls),
  ].join("");
}
