// ---------------------------------------------------------------
// types.ts — shared TypeScript types for AirAware.
// Each src/*.ts file compiles to dist/*.js and is loaded in order by index.html.
// ---------------------------------------------------------------

type BandKey = "good" | "moderate" | "sensitive" | "unhealthy" | "very-unhealthy" | "hazardous";

/** One row of the US EPA AQI scale. */
interface AqiBand {
  key: BandKey;
  label: string;
  min: number;
  max: number;
  color: string;
  icon: string;
  advice: string;
}

/** A city we can request air quality for. */
interface City {
  id: string;
  name: string;
  country: string;
  latitude: number;
  longitude: number;
  custom?: boolean;
}

/** Shape of one result from the Open-Meteo geocoding API. */
interface GeocodeResult {
  id: number;
  name: string;
  country?: string;
  admin1?: string;
  latitude: number;
  longitude: number;
}

interface GeocodeResponse {
  results?: GeocodeResult[];
}

/** Shape of the Open-Meteo Air Quality API response we request. */
interface AirQualityResponse {
  latitude: number;
  longitude: number;
  timezone: string;
  current: {
    time: string;
    us_aqi: number | null;
    pm2_5: number | null;
    pm10: number | null;
    nitrogen_dioxide: number | null;
    ozone: number | null;
  };
  hourly: {
    time: string[];
    us_aqi: (number | null)[];
  };
}

/** One hourly AQI sample used by the trend chart. */
interface TrendPoint {
  label: string;
  aqi: number;
}

/** Everything the UI needs to draw a city card and the trend chart. */
interface CityReading {
  city: City;
  aqi: number;
  band: AqiBand;
  pm25: number | null;
  pm10: number | null;
  no2: number | null;
  ozone: number | null;
  updated: string;
  trend: TrendPoint[];
  sample: boolean;
}

/** Per-city loading state, so each card can render independently. */
type Slot =
  | { status: "loading" }
  | { status: "ready"; reading: CityReading }
  | { status: "error"; message: string };
