// ---------------------------------------------------------------
// api.ts — typed Fetch API calls to Open-Meteo (free, no API key).
// Docs: https://open-meteo.com/en/docs/air-quality-api
// ---------------------------------------------------------------

const AIR_API = "https://air-quality-api.open-meteo.com/v1/air-quality";
const GEO_API = "https://geocoding-api.open-meteo.com/v1/search";

const DEFAULT_CITIES: City[] = [
  { id: "hyderabad", name: "Hyderabad", country: "India", latitude: 17.385, longitude: 78.4867 },
  { id: "delhi", name: "Delhi", country: "India", latitude: 28.6139, longitude: 77.209 },
  { id: "mumbai", name: "Mumbai", country: "India", latitude: 19.076, longitude: 72.8777 },
  { id: "bengaluru", name: "Bengaluru", country: "India", latitude: 12.9716, longitude: 77.5946 },
  { id: "chennai", name: "Chennai", country: "India", latitude: 13.0827, longitude: 80.2707 },
  { id: "kolkata", name: "Kolkata", country: "India", latitude: 22.5726, longitude: 88.3639 },
  { id: "london", name: "London", country: "United Kingdom", latitude: 51.5074, longitude: -0.1278 },
  { id: "beijing", name: "Beijing", country: "China", latitude: 39.9042, longitude: 116.4074 },
];

/** Typed wrapper around fetch(): throws on HTTP errors and returns parsed JSON as T. */
async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed (${response.status})`);
  }
  return (await response.json()) as T;
}

/**
 * Runtime type guard: TypeScript types disappear at runtime, so we check that
 * the API really returned the shape declared in AirQualityResponse before using it.
 */
function isAirQualityResponse(value: unknown): value is AirQualityResponse {
  if (typeof value !== "object" || value === null) return false;
  const v = value as Record<string, unknown>;
  const current = v.current as Record<string, unknown> | undefined;
  const hourly = v.hourly as Record<string, unknown> | undefined;
  return (
    typeof current === "object" && current !== null && typeof current.time === "string" &&
    typeof hourly === "object" && hourly !== null &&
    Array.isArray(hourly.time) && Array.isArray(hourly.us_aqi) &&
    hourly.time.length === hourly.us_aqi.length
  );
}

/** Fetch the current AQI plus the last 72 hours for one city. */
async function fetchAirQuality(city: City): Promise<CityReading> {
  const params = new URLSearchParams({
    latitude: String(city.latitude),
    longitude: String(city.longitude),
    current: "us_aqi,pm2_5,pm10,nitrogen_dioxide,ozone",
    hourly: "us_aqi",
    past_days: "3",
    forecast_days: "1",
    timezone: "auto",
  });
  const data = await getJson<unknown>(`${AIR_API}?${params.toString()}`);
  if (!isAirQualityResponse(data)) {
    throw new Error("Unexpected response from the air-quality service");
  }

  const trend = parseTrend(data);
  const currentAqi = data.current.us_aqi ?? (trend.length ? trend[trend.length - 1].aqi : null);
  if (currentAqi === null) {
    throw new Error("No AQI data available for this location");
  }

  const aqi = Math.round(currentAqi);
  return {
    city,
    aqi,
    band: getBand(aqi),
    pm25: data.current.pm2_5,
    pm10: data.current.pm10,
    no2: data.current.nitrogen_dioxide,
    ozone: data.current.ozone,
    updated: formatStamp(data.current.time),
    trend,
    sample: false,
  };
}

/** Keep only hours up to "now" that actually have a value. */
function parseTrend(data: AirQualityResponse): TrendPoint[] {
  const now = data.current.time;
  const points: TrendPoint[] = [];
  data.hourly.time.forEach((time, index) => {
    const value = data.hourly.us_aqi[index];
    if (time <= now && value !== null && value !== undefined) {
      points.push({ label: formatStamp(time), aqi: Math.round(value) });
    }
  });
  // The API returns 3 past days plus today so far; show exactly the last 72 hours.
  return points.slice(-72);
}

/** Look up cities by name (used by the search box). */
async function searchCities(query: string): Promise<GeocodeResult[]> {
  const params = new URLSearchParams({ name: query, count: "5", language: "en", format: "json" });
  const data = await getJson<GeocodeResponse>(`${GEO_API}?${params.toString()}`);
  return data.results ?? [];
}

// ---------- Offline fallback so the page is still explorable without network ----------

function hashString(text: string): number {
  let hash = 2166136261;
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

/** Deterministic, clearly-labelled sample data (daily wave + a little noise). */
function sampleReading(city: City): CityReading {
  const seed = hashString(city.id);
  const base = 35 + (seed % 150);
  const phase = (seed % 628) / 100;
  const trend: TrendPoint[] = [];
  for (let i = 0; i < 72; i++) {
    const wave = Math.sin((i / 24) * Math.PI * 2 + phase) * base * 0.28;
    const noise = Math.sin(i * 1.7 + seed) * base * 0.07;
    const aqi = Math.max(6, Math.round(base + wave + noise));
    trend.push({ label: `Day ${Math.floor(i / 24) + 1}, ${String(i % 24).padStart(2, "0")}:00`, aqi });
  }
  const aqi = trend[trend.length - 1].aqi;
  return {
    city,
    aqi,
    band: getBand(aqi),
    pm25: Math.round(aqi * 0.38 * 10) / 10,
    pm10: Math.round(aqi * 0.62 * 10) / 10,
    no2: Math.round(aqi * 0.25 * 10) / 10,
    ozone: Math.round(aqi * 0.5 * 10) / 10,
    updated: "sample data",
    trend,
    sample: true,
  };
}
